import json
import os


def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(
            {
                "service": "lambda-python-api",
                "status": "ok",
                "environment": os.getenv("APP_ENV", "unknown"),
                "eventType": event.get("requestContext", {}).get("http", {}).get("method", "unknown"),
            }
        ),
    }
